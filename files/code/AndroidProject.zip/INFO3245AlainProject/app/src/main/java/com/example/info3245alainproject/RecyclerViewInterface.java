package com.example.info3245alainproject;

public interface RecyclerViewInterface {
    void onItemClick(int position);

    void onLongItemClick(int position);

}
