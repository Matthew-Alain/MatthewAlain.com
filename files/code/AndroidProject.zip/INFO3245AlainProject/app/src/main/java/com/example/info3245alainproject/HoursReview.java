package com.example.info3245alainproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class HoursReview extends AppCompatActivity implements RecyclerViewInterface, ISelectedData {

    private ArrayList<HoursModal> hoursModalArrayList;
    private DBHandler dbHandler;
    private HoursRVAdapter hoursRVAdapter;
    private RecyclerView hoursRV;
    Button btnSendHours, btnBackFromReview;
    private int position;
    private static final int STORAGE_PERMISSION_CODE = 101;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hours_review);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSendHours = findViewById(R.id.btnSendHours);
        btnBackFromReview = findViewById(R.id.btnBackFromReview);

        hoursModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(this);

        //Get all hours from the database and store them in a modal list
        hoursModalArrayList = dbHandler.readHours();

        // Pass the modal list to the RV adapter class
        hoursRVAdapter = new HoursRVAdapter(hoursModalArrayList, this);
        hoursRV = findViewById(R.id.idRVHours);

        // Set the layout manager for the recycler view
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        hoursRV.setLayoutManager(linearLayoutManager);

        // Set the adapter to the recycler view
        hoursRV.setAdapter(hoursRVAdapter);

        btnSendHours.setOnClickListener(v -> {
            checkStoragePermissionAndExport();
        });

        btnBackFromReview.setOnClickListener(v -> {
            finish();
        });
    }

    //Creates the email intent to send the file
    private void sendEmail(File directory) {

        //Gets the current month and year to be used in the subject line
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH)+1;
        String monthFormat;

        if(month < 10){
            monthFormat = "0" + month;
        }else{
            monthFormat = "" + month;
        }

        //Sets the subject line to the school owner's desired format
        String subject = year + " " + monthFormat + " MA Work Hours";

        String body;
        body = "Hello Sir! Here are my work hours for "+monthFormat+" "+year+".";

        //Only requests for email apps to be selected
        Intent selectorIntent = new Intent(Intent.ACTION_SENDTO);
        selectorIntent.setData(Uri.parse("mailto:"));

        //Adds the target email address, subject and body to the email
        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"Matthew.Alain878@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, body.toString());

        //Creates a link to the file using the provided directory and name of the file, and attaches it to the email
        File file = new File(directory, "work_hours.xls");
        Uri contentUri = FileProvider.getUriForFile(this, "com.example.info3245alainproject.fileprovider", file);
        emailIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
        emailIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        //Attach the email intent to the intent to launch an email app, then launch the intent
        emailIntent.setSelector( selectorIntent );
        this.startActivity(Intent.createChooser(emailIntent, "Send email..."));
    }

    //When a record is clicked, pass the date to the hours input activity
    @Override
    public void onItemClick(int position) {

        String dateToPass = hoursModalArrayList.get(position).getDate();

        int year = Integer.parseInt(dateToPass.substring(0,4));
        int month = Integer.parseInt(dateToPass.substring(5,7));
        int day = Integer.parseInt(dateToPass.substring(8,10));

        Intent intent = new Intent(this, HoursInput.class);
        intent.putExtra("year", year);
        intent.putExtra("month", month);
        intent.putExtra("day", day);
        setResult(RESULT_OK, intent);
        startActivity(intent);
    }

    //When a record is long clicked, show a confirmation dialog
    @Override
    public void onLongItemClick(int position) {
        DeleteHoursConfirmation dialog = new DeleteHoursConfirmation();
        this.position = position;
        dialog.show(getSupportFragmentManager(), "DeleteConfirmationDialog");
    }

    //This looks weird, but it refreshes the activity when a record is deleted
    @Override
    public void onRestart(){
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

    //This is called when the confirmation dialog is closed
    @Override
    public void onSelectedData(String string) {
        if(string.equals("Yes")){
            dbHandler.deleteHours(hoursModalArrayList.get(position).getDate());
            finish();
            startActivity(getIntent());
        }
    }

    //Necessary functions to confirm storage permission for exporting the file
    private void checkStoragePermissionAndExport() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            exportData();
        } else {
            requestStoragePermission();
        }
    }
    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(this, "Storage permission is required to export data.", Toast.LENGTH_SHORT).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                exportData();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Gets the data to be sent to the excel file
    ArrayList<String> getData(){

        ArrayList<String> dataAsString = new ArrayList<>();
        hoursModalArrayList = dbHandler.readHours();

        for(int i = 0; i < hoursModalArrayList.size(); i++){

            String date = hoursModalArrayList.get(i).getDate();
            String startTime = hoursModalArrayList.get(i).getStartTimeDisplay();
            String endTime = hoursModalArrayList.get(i).getEndTimeDisplay();
            String totalTime = hoursModalArrayList.get(i).getTotalTime();

            String day = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                day = LocalDate.parse(date).getDayOfWeek().toString();
            }
            day = day.substring(0, 1) + day.substring(1).toLowerCase();

            dataAsString.add(day + "," + date + "," + startTime + "," + endTime + "," + totalTime);
        }

        return dataAsString;
    }

    //Exports the data to the excel file
    private void exportData() {

        //Gets an array list of the hours to be exported
        ArrayList<String> exportedHours = getData();

        // 1. Put the string data into a modal list
        List<ExcelExporter.HoursModal> hoursData = new ArrayList<>();

        for(int i = 0; i < exportedHours.size(); i++){
            String[] data = exportedHours.get(i).split(",");
            hoursData.add(new ExcelExporter.HoursModal(data[0], data[1], data[2], data[3], data[4]));
        }

        // 2. Define the file path
        String fileName = "work_hours.xls";
        File directory = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        String filePath = new File(directory, fileName).getAbsolutePath();

        // 3. Export the data
        boolean success = ExcelExporter.exportHoursToExcel(hoursData, filePath);

        // 4. Show a message
        if (success) {
            Toast.makeText(this, "Data exported to " + filePath, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show();
        }

        sendEmail(directory);
    }
}