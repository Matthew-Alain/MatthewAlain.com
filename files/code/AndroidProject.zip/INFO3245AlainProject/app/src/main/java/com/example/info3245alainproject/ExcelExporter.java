package com.example.info3245alainproject;

import java.io.File;
import java.io.IOException;
import java.util.List;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExcelExporter {

    //Creates the modal for the hours to be exported
    public static class HoursModal {
        public String day, date, startTimeDisplay, endTimeDisplay, totalTime;
        public HoursModal(String day, String date, String startTimeDisplay, String endTimeDisplay, String totalTime) {
            this.date = date;
            this.day = day;
            this.startTimeDisplay = startTimeDisplay;
            this.endTimeDisplay = endTimeDisplay;
            this.totalTime = totalTime;
        }
    }

    public static boolean exportHoursToExcel(List<HoursModal> data, String filePath) {
        try {
            //Creates the excel file at the specified filepath
            File file = new File(filePath);
            WritableWorkbook workbook = Workbook.createWorkbook(file);
            WritableSheet sheet = workbook.createSheet("Hours Data", 0); // Sheet name and index

            // Add headers
            sheet.addCell(new Label(0, 0, "Day"));
            sheet.addCell(new Label(1, 0, "Date"));
            sheet.addCell(new Label(2, 0, "Start"));
            sheet.addCell(new Label(3, 0, "End"));
            sheet.addCell(new Label(4, 0, "Total"));

            // Add data rows
            for (int i = 0; i < data.size(); i++) {
                HoursModal hours = data.get(i);
                sheet.addCell(new Label(0, i + 1, hours.day));
                sheet.addCell(new Label(1, i + 1, hours.date));
                sheet.addCell(new Label(2, i + 1, hours.startTimeDisplay));
                sheet.addCell(new Label(3, i + 1, hours.endTimeDisplay));
                sheet.addCell(new Label(4, i + 1, hours.totalTime));
            }

            workbook.write();
            workbook.close();
            return true; // Success
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Failure
        } catch (RowsExceededException e) {
            throw new RuntimeException(e);
        } catch (WriteException e) {
            throw new RuntimeException(e);
        }
    }
}