package com.example.info3245alainproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CurriculumSelect extends AppCompatActivity {

    Button btnTigerContent, btnWOYContent, btnCamoRedContent,
            btn1BRContent, btnBBContent, btnBackFromCurriculum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_curriculum_select);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnTigerContent = findViewById(R.id.btnTigerContent);
        btnWOYContent = findViewById(R.id.btnWOYContent);
        btnCamoRedContent = findViewById(R.id.btnCamoRedContent);
        btn1BRContent = findViewById(R.id.btn1BRContent);
        btnBBContent = findViewById(R.id.btnBBContent);
        btnBackFromCurriculum = findViewById(R.id.btnBackFromCurriculum);

        btnBackFromCurriculum.setOnClickListener(v -> {
            finish();
        });

        //Starts the next activity, passing the selected rank to get the curriculum
        btnTigerContent.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumDisplay.class);
            intent.putExtra("selectedRank", "Tigers");
            startActivity(intent);
        });

        btnWOYContent.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumDisplay.class);
            intent.putExtra("selectedRank", "WOY");
            startActivity(intent);
        });

        btnCamoRedContent.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumDisplay.class);
            intent.putExtra("selectedRank", "Camo above");
            startActivity(intent);
        });

        btn1BRContent.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumDisplay.class);
            intent.putExtra("selectedRank", "1BR");
            startActivity(intent);
        });

        btnBBContent.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumDisplay.class);
            intent.putExtra("selectedRank", "Black Belts");
            startActivity(intent);
        });


    }
}