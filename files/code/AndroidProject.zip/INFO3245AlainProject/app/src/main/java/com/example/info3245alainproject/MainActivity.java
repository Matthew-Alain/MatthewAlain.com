package com.example.info3245alainproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {

    Button btnGoToInput, btnGoToReview, btnGoToQuote, btnGoToCurriculum, btnGoToNotifs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnGoToInput = findViewById(R.id.btnGoToInput);
        btnGoToReview = findViewById(R.id.btnGoToReview);
        btnGoToQuote = findViewById(R.id.btnGoToQuote);
        btnGoToCurriculum = findViewById(R.id.btnGoToCurriculum);
        btnGoToNotifs = findViewById(R.id.btnGoToNotifs);

        btnGoToInput.setOnClickListener(v -> {
            Intent intent = new Intent(this, HoursInput.class);
            startActivity(intent);
        });

        btnGoToQuote.setOnClickListener(v -> {
            Intent intent = new Intent(this, MotivationalQuote.class);
            startActivity(intent);
        });

        btnGoToReview.setOnClickListener(v -> {
            Intent intent = new Intent(this, HoursReview.class);
            startActivity(intent);
        });

        btnGoToCurriculum.setOnClickListener(v -> {
            Intent intent = new Intent(this, CurriculumSelect.class);
            startActivity(intent);
        });

        btnGoToNotifs.setOnClickListener(v -> {
            Intent intent = new Intent(this, NotificationSettings.class);
            startActivity(intent);
        });


        //This method is not used anymore, but is left in for demonstration purposes
        //This was used to set a text view that no longer exists with the FCM token
        //so that it could be copied into the Firebase console. If this app is installed on
        //any additional devices, this will need to be re-used to get their target FCM token
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Fetching FCM registration token failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
}