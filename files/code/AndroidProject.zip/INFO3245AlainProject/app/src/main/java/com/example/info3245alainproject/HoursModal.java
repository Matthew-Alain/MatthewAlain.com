package com.example.info3245alainproject;

public class HoursModal {
    private String date;
    private String startTime;
    private String startTimeDisplay;
    private String endTime;
    private String endTimeDisplay;
    private String totalTime;
    public String getDate(){ return date; }
    public void setDate(String date) { this.date = date; }
    public String getStartTime(){ return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }
    public String getEndTime(){ return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
    public String getTotalTime() { return totalTime; }
    public void setTotalTime(String totalTime) { this.totalTime = totalTime; }
    public String getStartTimeDisplay() { return startTimeDisplay; }
    public void setStartTimeDisplay(String startTimeDisplay) { this.startTimeDisplay = startTimeDisplay; }
    public String getEndTimeDisplay() { return endTimeDisplay; }
    public void setEndTimeDisplay(String endTimeDisplay) { this.endTimeDisplay = endTimeDisplay; }

    // constructor
    public HoursModal(String date, String startTime, String endTime, String totalTime,
                      String startTimeDisplay, String endTimeDisplay)
    {
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.totalTime = totalTime;
        this.startTimeDisplay = startTimeDisplay;
        this.endTimeDisplay = endTimeDisplay;
    }

}