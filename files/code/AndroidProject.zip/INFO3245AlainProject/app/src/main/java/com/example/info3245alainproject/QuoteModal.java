package com.example.info3245alainproject;

public class QuoteModal {
    private int id;
    private String quote;
    private String speaker;

    public String getQuote() { return quote; }
    public void quote(String quote) { this.quote = quote; }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getSpeaker() { return speaker; }

    public void setSpeaker(String speaker) { this.speaker = speaker; }

    // constructor
    public QuoteModal(String quote, String speaker)
    {
        this.quote = quote;
        this.speaker = speaker;
    }

}