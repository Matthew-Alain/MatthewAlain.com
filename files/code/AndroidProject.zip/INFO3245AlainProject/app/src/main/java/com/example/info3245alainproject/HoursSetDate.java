package com.example.info3245alainproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HoursSetDate extends AppCompatActivity {

    DatePicker datePicker;
    Button btnBackFromDate, btnSaveNewDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hours_set_date);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        datePicker = findViewById(R.id.datePicker);
        btnBackFromDate = findViewById(R.id.btnBackFromDate);
        btnSaveNewDate = findViewById(R.id.btnSaveNewDate);

        //Returns back to the previous activity with no new date passed
        btnBackFromDate.setOnClickListener(v -> {
            Intent intent = new Intent();
            setResult(RESULT_CANCELED, intent);
            finish();
        });

        //Pass the currently selected date back to the previous activity
        btnSaveNewDate.setOnClickListener(v -> {
            int year = datePicker.getYear();
            int month = datePicker.getMonth()+1;
            int day = datePicker.getDayOfMonth();

            Intent intent = new Intent();
            intent.putExtra("year", year);
            intent.putExtra("month", month);
            intent.putExtra("day", day);
            setResult(RESULT_OK, intent);
            finish();
        });


    }
}