package com.example.info3245alainproject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.DialogFragment;

public class DeleteHoursConfirmation extends DialogFragment {
    private ISelectedData mCallBack;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction.
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity()); //Builds dialog box

        builder.setMessage("Would you like to remove the listed hours for this day?")
                .setPositiveButton("Yes", (dialog, id) -> {
                    mCallBack.onSelectedData("Yes");
                })
                .setNegativeButton("No", (dialog, id) -> {
                    mCallBack.onSelectedData("No");
                });
        return builder.create();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallBack = (ISelectedData) activity;
        } catch (ClassCastException e) {
            Log.d("DeleteHoursConfirmation", "Activity doesn't implement the interface");
        }
    }
}
