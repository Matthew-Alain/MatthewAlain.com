package com.example.info3245alainproject;

public class CurriculumModal {
    String rank, block, strike, kick, form, weapon, sparring, boards;
    public CurriculumModal(String rank, String block, String strike, String kick, String form, String weapon, String sparring, String boards){
        this.rank = rank;
        this.block = block;
        this.strike = strike;
        this.kick = kick;
        this.form = form;
        this.weapon = weapon;
        this.sparring = sparring;
        this.boards = boards;
    }
    public String getRank(){ return rank; }
    public String getBlock(){ return block; }
    public String getStrike(){ return strike; }
    public String getKick(){ return kick; }
    public String getForm(){ return form; }
    public String getWeapon(){ return weapon; }
    public String getSparring(){ return sparring; }
    public String getBoards(){ return boards; }
    public void setRank(String rank){ this.rank = rank; }
    public void setBlock(String block){ this.block = block; }
    public void setStrike(String strike){ this.strike = strike; }
    public void setKick(String kick){ this.kick = kick; }
    public void setForm(String form){ this.form = form; }
    public void setWeapon(String weapon){ this.weapon = weapon; }
    public void setSparring(String sparring){ this.sparring = sparring; }
    public void setBoards(String boards){ this.boards = boards; }

}
