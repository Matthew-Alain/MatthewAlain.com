package com.example.info3245alainproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MotivationalQuote extends AppCompatActivity {

    TextView txtQuote, txtSpeaker;
    private DBHandler dbHandler = new DBHandler(this);
    Button btnNewQuote, btnNewFont, btnNewBackground, btnGoToSubmit, btnBackFromQuote;
    private ArrayList<QuoteModal> quoteModalArrayList = new ArrayList<>();
    ImageView imgBackground;
    int currentQuote, currentFont, currentBackground;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_motivational_quote);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtQuote = findViewById(R.id.txtQuote);
        btnNewQuote = findViewById(R.id.btnNewQuote);
        btnNewFont = findViewById(R.id.btnNewFont);
        btnNewBackground = findViewById(R.id.btnNewBackground);
        btnGoToSubmit = findViewById(R.id.btnGoToSubmit);
        btnBackFromQuote = findViewById(R.id.btnBackFromQuote);
        txtSpeaker = findViewById(R.id.txtSpeaker);
        imgBackground = findViewById(R.id.imgBackground);

        //When the activity is called, it generates a random quote
        imgBackground.setVisibility(View.INVISIBLE);
        setQuote(new View(this));
        setFont(new View(this));
        setBackground(new View(this));

        btnGoToSubmit.setOnClickListener(v -> {
            Intent intent = new Intent(this, SubmitNewQuote.class);
            startActivity(intent);
        });

        btnBackFromQuote.setOnClickListener(v -> {
            finish();
        });

    }

    //Randomizes the quote
    public void setQuote(View v){
        //Get array list of all quote modal objects so the getter methods can be used
        quoteModalArrayList = dbHandler.readQuotes();

        //Check if there are any quotes in the database
        int listSize = quoteModalArrayList.size();
        if(listSize == 0){
            Toast.makeText(this, "No quotes found", Toast.LENGTH_SHORT).show();
        }else {
            int quoteNum;
            if(listSize != 1) { //If there is only one quote, it cannot generate a new one
                do {
                    quoteNum = (int) (Math.random() * listSize + 1);
                } while (quoteNum == currentQuote); //Prevents the same quote from being generated
                currentQuote = quoteNum;
                String currentQuote = dbHandler.getQuote(quoteNum)[0];
                String currentSpeaker = dbHandler.getQuote(quoteNum)[1];
                txtQuote.setText("\""+currentQuote+"\"");   //Adds quotation marks
                txtSpeaker.setText("-"+currentSpeaker);     //Adds hyphen
            }

        }
    }

    //Randomizes the font
    public void setFont(View v){
        int fontNum;
        do {
            fontNum = (int) (Math.random() * 4 + 1);
        }while(fontNum == currentFont);     //Prevents the same font from being generated
        currentFont = fontNum;

        //Sets the typeface based on the generated number
        switch (fontNum){
            case 1:
                @SuppressLint({"NewApi", "LocalSuppress"}) Typeface comicneue = getResources().getFont(R.font.comicneue);
                txtQuote.setTypeface(comicneue);
                txtSpeaker.setTypeface(comicneue);
                break;
            case 2:
                @SuppressLint({"NewApi", "LocalSuppress"}) Typeface caveat = getResources().getFont(R.font.caveat);
                txtQuote.setTypeface(caveat);
                txtSpeaker.setTypeface(caveat);
                break;
            case 3:
                @SuppressLint({"NewApi", "LocalSuppress"}) Typeface cedarvillecursive = getResources().getFont(R.font.cedarvillecursive);
                txtQuote.setTypeface(cedarvillecursive);
                txtSpeaker.setTypeface(cedarvillecursive);
                break;
            case 4:
                @SuppressLint({"NewApi", "LocalSuppress"}) Typeface pinyonscript = getResources().getFont(R.font.pinyonscript);
                txtQuote.setTypeface(pinyonscript);
                txtSpeaker.setTypeface(pinyonscript);
                break;
        }
    }

    //Randomizes the background
    public void setBackground(View v){
        imgBackground.setVisibility(View.VISIBLE);

        int backgroundNum;
        do {
            backgroundNum = (int) (Math.random() * 5 + 1);
        }while(backgroundNum == currentBackground);     //Prevents the same background from being generated
        currentBackground = backgroundNum;

        //Sets the background based on the generated number, and changes the text color to be more readable
        switch (backgroundNum){
            case 1:
                imgBackground.setBackgroundResource(R.drawable.clouds);
                txtQuote.setTextColor(Color.parseColor("#000000"));
                txtSpeaker.setTextColor(Color.parseColor("#000000"));
                break;
            case 2:
                imgBackground.setBackgroundResource(R.drawable.gym);
                txtQuote.setTextColor(Color.parseColor("#FFFFFF"));
                txtSpeaker.setTextColor(Color.parseColor("#FFFFFF"));
                break;
            case 3:
                imgBackground.setBackgroundResource(R.drawable.mountaintop);
                txtQuote.setTextColor(Color.parseColor("#000000"));
                txtSpeaker.setTextColor(Color.parseColor("#000000"));
                break;
            case 4:
                imgBackground.setBackgroundResource(R.drawable.ocean);
                txtQuote.setTextColor(Color.parseColor("#000000"));
                txtSpeaker.setTextColor(Color.parseColor("#000000"));
                break;
            case 5:
                imgBackground.setBackgroundResource(R.drawable.path);
                txtQuote.setTextColor(Color.parseColor("#000000"));
                txtSpeaker.setTextColor(Color.parseColor("#000000"));
        }
    }

}

