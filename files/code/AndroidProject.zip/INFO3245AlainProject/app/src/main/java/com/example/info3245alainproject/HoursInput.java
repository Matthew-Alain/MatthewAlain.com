package com.example.info3245alainproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;

public class HoursInput extends AppCompatActivity {

    TimePicker time;
    TextView date;
    String dateValue;
    Button btnBackFromInput, btnSaveStartTime, btnSaveEndTime, btnToChangeDate;
    Boolean fromReview = false;
    private DBHandler dbHandler;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hours_input);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        time = findViewById(R.id.timePicker);
        date = findViewById(R.id.txtDate);
        btnBackFromInput = findViewById(R.id.btnBackFromInput);
        btnSaveStartTime = findViewById(R.id.btnSaveStartTime);
        btnSaveEndTime = findViewById(R.id.btnSaveEndTime);
        btnToChangeDate = findViewById(R.id.btnToChangeDate);

        dbHandler = new DBHandler(this);

        //If there was a specific intent that called this activity, get the date from it
        if(getIntent().getExtras() != null){
            fromReview = true;
            int year = getIntent().getIntExtra("year", 0);
            int month = getIntent().getIntExtra("month", 0);
            int day = getIntent().getIntExtra("day", 0);
            setDate(year, month, day);
        }else { //If there wasn't, get the current date
            LocalDate now = LocalDate.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            int day = now.getDayOfMonth();
            setDate(year, month, day);
        }

        btnBackFromInput.setOnClickListener(v -> {
            finish();
        });

        btnSaveStartTime.setOnClickListener(v -> {
            submitTime("Start");
        });

        btnSaveEndTime.setOnClickListener(v -> {
            submitTime("End");
        });

        //Create an intent to receive a new date from the next activity
        Intent intent = new Intent(this, HoursSetDate.class);
        btnToChangeDate.setOnClickListener(v -> {
            startActivityForResult(intent, 1);
        });

    }

    //Formats the date as a string to be displayed
    @SuppressLint("NewApi")
    private void setDate(int year, int month, int day) {

        String yearValue = String.valueOf(year);
        String monthValue = String.valueOf(month);
        String dayValue = String.valueOf(day);

        if(month < 10){
            monthValue = "0" + month;
        }
        if(day < 10){
            dayValue = "0" + day;
        }

        dateValue = yearValue + "-" + monthValue + "-" + dayValue;

        //Displays the word for the month rather than the number for easier readability
        String monthLabel = Month.of(month).getDisplayName(TextStyle.FULL_STANDALONE, Locale.ENGLISH);
        String dateFormatted = monthLabel + " " + day + ", " + year;
        date.setText(dateFormatted);
    }

    //If the activity was called from the "review hours" activity, get the date from there
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            int year = data.getIntExtra("year", 0);
            int month = data.getIntExtra("month", 0);
            int day = data.getIntExtra("day", 0);
            setDate(year, month, day);
        }
    }

    //Saves the time to the database
    public void submitTime(String startEnd){

        int hour = time.getHour();
        int minute = time.getMinute();
        String timeValue;
        String timeFormat;
        String ampm;

        //Converts the time into a properly formatted string
        String hourValue = String.valueOf(hour);
        String minuteValue = String.valueOf(minute);
        if(hour==0){
            hourValue = "00";
        }else if(hour<10){
            hourValue = "0" + hour;
        }
        if(minute==0){
            minuteValue = "00";
        }else if(minute<10){
            minuteValue = "0" + minute;
        }
        timeValue = hourValue + ":" + minuteValue;

        //Determines AM and PM
        if (hour == 0) {
            hour += 12;
            ampm = "AM";
        } else if (hour == 12) {
            ampm = "PM";
        } else if (hour > 12) {
            hour -= 12;
            ampm = "PM";
        } else {
            ampm = "AM";
        }

        if(minute == 0){
            timeFormat = hour + ":00 " + ampm;
        }else if (minute < 10) {
            timeFormat = hour + ":0" + minute + " " + ampm;
        }else{
            timeFormat = hour + ":" + minute + " " + ampm;
        }

        //Adds the time to the database and confirms it
        dbHandler.addTime(startEnd, dateValue, timeValue, timeFormat);
        Toast.makeText(this, startEnd + " time saved", Toast.LENGTH_SHORT).show();

        //If the activity was started from the review hours activity, return there
        if(fromReview){
            fromReview = false;
            finish();
        }
    }

}