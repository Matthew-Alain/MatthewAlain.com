package com.example.info3245alainproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "staffDatabase";
    private static final int DB_VERSION = 1;


    // Constructor for the database handler
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Create the database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the staff quotes table
        String query = "CREATE TABLE staffQuotes ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "  // this is the primary key
                + "quote TEXT, "                            // this is the quote
                + "speaker TEXT)";                          // this is the speaker

        //execute the query
        db.execSQL(query);

        //Populate the database initially with quotes
        query = "INSERT INTO staffQuotes (quote, speaker) VALUES "
                + "('I have to make them do things for half an hour', 'Mr. White'), "
                + "('Demoted to yellow belt', 'Mr. White'), "
                + "('PLEASE', 'Mr. White'), "
                + "('*Slaps watch aggressively*', 'Mr. White'), "
                + "('Don''t tell Ms. Chumber', 'Mr. White'), "
                + "('Hey. Boys.', 'Mr. White'), "
                + "('I shouldn''t have to say that twice', 'Mr. White'), "
                + "('Yeah, Mr. Alain', 'Mr. White'), "
                + "('Success is not final, failure is not fatal. It is the courage to continue that counts', 'Winston Churchill'), "
                + "('Don''t settle for average. Bring your best to the moment. Then, whether it fails or succeeds, at least you know you gave it all you had', 'Angela Bassett'), "
                + "('I''m a success today because I had a friend who believed in me and I didn''t have the heart to let him down', 'Abraham Lincoln'), "
                + "('The secret stuff was inside you all along', 'Michael Jordan, Space Jam'), "
                + "('Nothing is impossible. Even the word itself says ''I''m Possible!''', 'Audrey Hepburn'), "
                + "('Skibidi', 'Mr. Fedi Mahdi'), "
                + "('Don''t stop when you''re tired. Stop when you''re done.','Unknown'), "
                + "('The sky''s the limit... for jumping','Mr. Sweeting'), "
                + "('If you set your mind to it, the percentages will work out','Mr. Sweeting'), "
                + "('If you fail, try again!','Ms. Chumber'), "
                + "('If you try hard, you won''t fail!','Mr. Fedi Mahdi'), "
                + "('But don''t forget, if you try hard, you still might fail','Mr. Fedi Mahdi'), "
                + "('The sky and the stars are in the same place, but are very different','Mr. Sweeting'), "
                + "('We need more water','Mr. Martin'), "
                + "('The sky and the stars never waited for anybody','Mr. Sweeting'), "
                + "('Stand positive','Mr. Fedi Mahdi'), "
                + "('I believe in you. You specifically, if you''re reading this quote it''s about you','Mr. Alain')";
        db.execSQL(query);

        //Create the table for work hours
        query = "CREATE TABLE hours ("
                + "date DATE PRIMARY KEY, "
                + "startTime TIME, "
                + "endTime TIME, "
                + "totalTime TEXT, "
                + "startTimeDisplay TEXT, "
                + "endTimeDisplay TEXT)";
        db.execSQL(query);

        //Create the table for curriculum
        query = "CREATE TABLE curriculum ("
                + "rank TEXT PRIMARY KEY, "
                + "block TEXT, "
                + "strike TEXT, "
                + "kick TEXT, "
                + "form TEXT, "
                + "weapon TEXT, "
                + "sparring TEXT, "
                + "boards TEXT)";
        db.execSQL(query);

        //Populate the database with the current semester curriculum.
        //In the future, if the app is updated with next semester's curriculum, this wiill be changed
        query = "INSERT INTO curriculum VALUES "
                + "('Tigers', 'Twin low block', 'Knife hand strike', '#2 round kick', " +
                    "'Songahm 2 first line', 'Single SJB', 'Spin hook kick', '#2 front kick'), "
                + "('WOY', 'Twin low block', 'Knife hand strike', '#1-4 round kick', " +
                    "'Songahm 2 first half', 'None', 'None', 'None'), "
                + "('Camo above', 'Double low block', 'Reverse palm heel strike', 'Front kick-round kick', " +
                    "'Choong Jung 1 (2nd half)', 'Single SJB', 'Spin hook kick', '#2 round kick'), "
                + "('1BR', 'None', 'None', 'None', 'Songahm 2 + Choong Jung 2', 'Jahng Bong', 'Spin hook kick', '#2 round kick + Palm heel strike'), "
                + "('Black Belts', 'None', 'None', 'None', 'Rank form', '1st degrees: Jahng Bong\n2nd-4th degrees: None', 'Spin hook kick', '#2 round kick')";
        db.execSQL(query);

        //Create table for user notification preferences
        query = "CREATE TABLE settings ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "monday INTEGER, "
                + "tuesday INTEGER, "
                + "wednesday INTEGER, "
                + "thursday INTEGER, "
                + "friday INTEGER, "
                + "saturday INTEGER, "
                + "EndOfWeek INTEGER, "
                + "EndOfMonth INTEGER)";
        db.execSQL(query);

        //Sets default preferences
        query = "INSERT INTO settings VALUES "
                + "(1, 0, 0, 0, 0, 0, 0, 0, 0)";
        db.execSQL(query);
    }

    //THIS IS FOR READING DATA
    public ArrayList<QuoteModal> readQuotes()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        //Read all quotes from the database
        Cursor cursorQuotes
                = db.rawQuery("SELECT * FROM staffQuotes", null);

        //Create an arraylist to store the quotes
        ArrayList<QuoteModal> quoteModalArrayList = new ArrayList<>();

        // Move cursor to first position
        if (cursorQuotes.moveToFirst()) {
            do {
                //Get the quote and speaker, and add them to the arraylist
                quoteModalArrayList.add(new QuoteModal(
                        cursorQuotes.getString(1),
                        cursorQuotes.getString(2)
                ));
            } while (cursorQuotes.moveToNext()); // Move cursor to next position
        }

        //Close cursor and return the quotes and speakers list
        cursorQuotes.close();
        return quoteModalArrayList;
    }

    //Gets a specific quote from the list given a specific id
    public String[] getQuote(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorQuotes
                = db.rawQuery("SELECT * FROM staffQuotes WHERE id = " + id, null);

        //Creates an array to store the quote and speaker, filled with default values in case there is an error
        String[] currentQuote = {"Default quote", "Default speaker"};

        if (cursorQuotes.moveToFirst()) {
                currentQuote[0] = cursorQuotes.getString(1);
                currentQuote[1] = cursorQuotes.getString(2);
        }
        cursorQuotes.close();
        return currentQuote;
    }

    //Add a new quote to the database
    public void addNewQuote(String quote, String speaker) {

        SQLiteDatabase db = this.getWritableDatabase();

        //Create an object to store the values to be added to the database
        ContentValues values = new ContentValues();

        //Pass the key and value pairs
        values.put("quote", quote);
        values.put("speaker", speaker);

        //Insert the quotes into the database
        db.insert("staffQuotes", null, values);

        db.close();
    }

    //Read all hours from the database
    public ArrayList<HoursModal> readHours()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        //Gets all records and sorts them by earliest date
        Cursor cursorHours
                = db.rawQuery("SELECT * FROM hours ORDER BY date ASC", null);

        ArrayList<HoursModal> hoursModalArrayList = new ArrayList<>();

        if (cursorHours.moveToFirst()) {
            do {
                hoursModalArrayList.add(new HoursModal(
                        cursorHours.getString(0),   //date
                        cursorHours.getString(1),   //start time
                        cursorHours.getString(2),   //end time
                        cursorHours.getString(3),   //total time
                        cursorHours.getString(4),   //start time display
                        cursorHours.getString(5)    //end time display
                ));
            } while (cursorHours.moveToNext());
        }
        cursorHours.close();
        return hoursModalArrayList;
    }

    //Add or update an hours record in the database
    public void addTime(String startEnd, String date, String time, String timeDisplay) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("date", date);
        //Whether the start or end time is being added
        if(startEnd.equals("Start")){
            values.put("startTime", time);
            values.put("startTimeDisplay", timeDisplay);
        }else if(startEnd.equals("End")){
            values.put("endTime", time);
            values.put("endTimeDisplay", timeDisplay);
        }

        //Whether the record needs to be updated or added
        if(dateAlreadyExists(date, db)){
            db.update("hours", values, "date = ?", new String[]{date});
        }else{
            db.insert("hours", null, values);
        }

        //Whenever a new value is added, the total hours calculation is run
        calculateTotalHours(date, db);
        db.close();
    }

    //Tests whether a date already exists in the database
    public Boolean dateAlreadyExists(String date, SQLiteDatabase db){

        Cursor cursor = db.rawQuery("SELECT * FROM hours WHERE date = '" + date + "'", null);

        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    //Used as part of the total hours calculation, determines whether a date has
    // both a start and end time
    public Boolean hasNoEndTime(String date, SQLiteDatabase db){
        Boolean isNull = db.rawQuery("SELECT * FROM hours WHERE date = '" + date + "' AND endTimeDisplay IS NULL", null).getCount() >0;
        Boolean isNone = db.rawQuery("SELECT * FROM hours WHERE date = '" + date + "' AND endTimeDisplay = '" + "None" + "'", null).getCount() >0;
        return isNull || isNone;
    }
    public Boolean hasNoStartTime(String date, SQLiteDatabase db){
        Boolean isNull = db.rawQuery("SELECT * FROM hours WHERE date = '" + date + "' AND startTimeDisplay IS NULL", null).getCount() >0;
        Boolean isNone = db.rawQuery("SELECT * FROM hours WHERE date = '" + date + "' AND startTimeDisplay = '" + "None" + "'", null).getCount() >0;
        return isNull || isNone;
    }

    //Determines the number of payable hours worked on a given day and updates the database
    public void calculateTotalHours(String date, SQLiteDatabase db){
        ContentValues values = new ContentValues();

        //If there is no start or end time, do not calculate the total hours, fill them with dummy values
        if(hasNoEndTime(date, db)){
            values.put("endTimeDisplay","None");
            values.put("totalTime", "N/A");
            db.update("hours", values, "date = ?", new String[]{date});
            return;
        }else if(hasNoStartTime(date, db)){
            values.put("startTimeDisplay","None");
            values.put("totalTime", "N/A");
            db.update("hours", values, "date = ?", new String[]{date});
            return;
        } else{
            //If there is a start and end time, calculate the total hours
            Cursor cursor = db.rawQuery("SELECT startTime, endTime FROM hours WHERE date = '" + date + "'", null);

            if(cursor.moveToFirst()) {
                String startTime = cursor.getString(0);
                String endTime = cursor.getString(1);

                String[] endTimeSplit = endTime.split(":");
                String[] startTimeSplit = startTime.split(":");

                int endHour = Integer.parseInt(endTimeSplit[0]);
                int endMinute = Integer.parseInt(endTimeSplit[1]);
                int startHour = Integer.parseInt(startTimeSplit[0]);
                int startMinute = Integer.parseInt(startTimeSplit[1]);

                int totalHour = endHour - startHour;        //Get the difference in hours
                int totalMinute = endMinute - startMinute;  //Get the difference in minutes

                if (totalMinute < 0) {
                    totalHour--;
                    totalMinute += 60;
                }

                String totalHourString = String.valueOf(totalHour);
                String totalMinuteString = String.valueOf(totalMinute);

                if (totalMinute < 10) {
                    totalMinuteString = "0" + totalMinute;
                }

                //Combine the hours and minutes into a single string
                values.put("totalTime", totalHourString + ":" + totalMinuteString);

                //Update the database with the total hours
                db.update("hours", values, "date = ?", new String[]{date});
                cursor.close();
            }
        }
    }

    //Removes hour record from database
    public void deleteHours(String date){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("hours", "date = ?", new String[]{date});
        db.close();
    }

    //Gets the curriculum for a specific rank
    public CurriculumModal getCurriculum(String rank)
    {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorQuotes
                = db.rawQuery("SELECT * FROM curriculum WHERE rank = '" + rank + "'", null);

        ArrayList<CurriculumModal> curriculumArrayList = new ArrayList<>();

        if (cursorQuotes.moveToFirst()) {
            do {
                curriculumArrayList.add(new CurriculumModal(
                        cursorQuotes.getString(0),
                        cursorQuotes.getString(1),
                        cursorQuotes.getString(2),
                        cursorQuotes.getString(3),
                        cursorQuotes.getString(4),
                        cursorQuotes.getString(5),
                        cursorQuotes.getString(6),
                        cursorQuotes.getString(7)
                ));
            } while (cursorQuotes.moveToNext());
        }

        //Passes the rank as a modal object so curriculum display can use the class' getter methods
        CurriculumModal modal = curriculumArrayList.get(0);

        cursorQuotes.close();
        return modal;
    }

    //Reads user preferences
    public ArrayList<Boolean> readSettings(){
        SQLiteDatabase db = this.getReadableDatabase();

        //In the current version of the databaes, there should never be more than one record, but
        //in the future, if this converted to a "users" table, the id will need to match the user
        Cursor cursor = db.rawQuery("SELECT * FROM settings WHERE id = 1", null);
        ArrayList<Boolean> settings = new ArrayList<>();
        if(cursor.moveToFirst()){
            settings.add(cursor.getInt(1)==1);
            settings.add(cursor.getInt(2)==1);
            settings.add(cursor.getInt(3)==1);
            settings.add(cursor.getInt(4)==1);
            settings.add(cursor.getInt(5)==1);
            settings.add(cursor.getInt(6)==1);
            settings.add(cursor.getInt(7)==1);
            settings.add(cursor.getInt(8)==1);
        }
        cursor.close();
        return settings;
    }

    //Updates the user preferences to determine whether checkboxes should be filled
    public void updateSetting(String day, Boolean settings){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(day, settings);
        db.update("settings", values, "id = ?", new String[]{"1"});

        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS staffQuotes");
        db.execSQL("DROP TABLE IF EXISTS hours");
        db.execSQL("DROP TABLE IF EXISTS curriculum");
        db.execSQL("DROP TABLE IF EXISTS settings");
        onCreate(db);
    }
}
