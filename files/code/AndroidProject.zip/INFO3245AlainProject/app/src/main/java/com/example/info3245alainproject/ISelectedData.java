package com.example.info3245alainproject;

public interface ISelectedData {
    void onSelectedData(String string);
}
