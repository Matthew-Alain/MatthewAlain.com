package com.example.info3245alainproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//This class is mostly copied from the in-class demo, but with the interface methods added to the end
public class HoursRVAdapter extends RecyclerView.Adapter<HoursRVAdapter.ViewHolder>{

    private final RecyclerViewInterface recyclerViewInterface;

    private ArrayList<HoursModal> hoursModalArrayList;

    public HoursRVAdapter(ArrayList<HoursModal> hoursModalArrayList, RecyclerViewInterface recyclerViewInterface){
        this.hoursModalArrayList = hoursModalArrayList;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hours_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HoursRVAdapter.ViewHolder holder, int position) {
        HoursModal modal = hoursModalArrayList.get(position);
        holder.hoursDateTV.setText(modal.getDate());
        holder.hoursStartTimeDisplayTV.setText(modal.getStartTimeDisplay());
        holder.hoursEndTimeDisplayTV.setText(modal.getEndTimeDisplay());
        holder.hoursTotalTimeTV.setText(modal.getTotalTime());
    }

    @Override
    public int getItemCount() {
        return hoursModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        // creating variables for our text views.
        private TextView hoursDateTV;
        private TextView hoursStartTimeDisplayTV;
        private TextView hoursEndTimeDisplayTV;
        private TextView hoursTotalTimeTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views
            hoursDateTV = itemView.findViewById(R.id.idTVHoursDate);
            hoursStartTimeDisplayTV = itemView.findViewById(R.id.idTVStartTime);
            hoursEndTimeDisplayTV = itemView.findViewById(R.id.idTVEndTime);
            hoursTotalTimeTV = itemView.findViewById(R.id.idTVTotal);

            //Gets the position of the item when clicked
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int pos = getAdapterPosition();
                        if(pos != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    recyclerViewInterface.onLongItemClick(getAdapterPosition());
                    return false;
                }
            });
        }
    }
}
