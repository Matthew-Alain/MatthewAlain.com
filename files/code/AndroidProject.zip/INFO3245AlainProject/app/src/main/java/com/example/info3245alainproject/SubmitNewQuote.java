package com.example.info3245alainproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SubmitNewQuote extends AppCompatActivity {

    private DBHandler dbHandler;
    EditText edtNewQuote, edtNewSpeaker;

    Button btnSubmitQuote, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_submit_new_quote);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHandler = new DBHandler(this);

        btnSubmitQuote = findViewById(R.id.btnSubmitQuote);
        btnBack = findViewById(R.id.btnBack);
        edtNewQuote = findViewById(R.id.edtNewQuote);
        edtNewSpeaker = findViewById(R.id.edtNewSpeaker);

        //Gets the inputted quote and speaker and adds it to the database
        btnSubmitQuote.setOnClickListener(v -> {
            String quote = edtNewQuote.getText().toString();
            String speaker = edtNewSpeaker.getText().toString();

            //Empty input validation
            if (quote.isBlank()) {
                Toast.makeText(this, "Please enter a quote", Toast.LENGTH_SHORT).show();
            }else if(speaker.isBlank()){
                Toast.makeText(this, "Please enter a speaker", Toast.LENGTH_SHORT).show();
            }else {
                dbHandler.addNewQuote(quote, speaker);
                Toast.makeText(this, "Quote Added", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        btnBack.setOnClickListener(v -> {
            finish();
        });

    }
}