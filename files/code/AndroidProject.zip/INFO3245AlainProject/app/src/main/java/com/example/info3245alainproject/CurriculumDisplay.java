package com.example.info3245alainproject;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CurriculumDisplay extends AppCompatActivity {

    TextView txtSelectedRank, txtBlock, txtStrike, txtKick, txtForm, txtWeapon, txtSparring, txtBoards;
    Button btnBackFromCurriculumDisplay, btnWatchBasics, btnWatchWeapon;
    String selectedRank, basics = "none", weapon = "none";
    MediaController mediaController;
    Uri uri;
    VideoView videoView;
    CurriculumModal curriculum;
    DBHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_curriculum_display);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtSelectedRank = findViewById(R.id.txtSelectedRank);
        txtBlock = findViewById(R.id.txtBlock);
        txtStrike = findViewById(R.id.txtStrike);
        txtKick = findViewById(R.id.txtKick);
        txtForm = findViewById(R.id.txtForm);
        txtWeapon = findViewById(R.id.txtWeapon);
        txtSparring = findViewById(R.id.txtSparring);
        txtBoards = findViewById(R.id.txtBoards);
        btnBackFromCurriculumDisplay = findViewById(R.id.btnBackFromCurriculumDisplay);
        btnWatchBasics = findViewById(R.id.btnWatchBasics);
        btnWatchWeapon = findViewById(R.id.btnWatchWeapon);
        videoView = findViewById(R.id.videoView);
        mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);

        //Sets what rank was passed to the activity
        selectedRank = getIntent().getStringExtra("selectedRank");
        txtSelectedRank.setText(selectedRank + " Material");

        db = new DBHandler(this);
        curriculum = db.getCurriculum(selectedRank); //Gets the curriculum from the selected rank

        //If there are no basics for the rank group, "None" is displayed only once
        if(curriculum.getBlock().equals("None")){
            txtBlock.setVisibility(View.INVISIBLE);
            txtKick.setVisibility(View.INVISIBLE);
        }else{
            txtBlock.setText(curriculum.getBlock());
            txtKick.setText(curriculum.getKick());
            txtBlock.setVisibility(View.VISIBLE);
            txtKick.setVisibility(View.VISIBLE);
        }
        txtStrike.setText(curriculum.getStrike());
        txtForm.setText(curriculum.getForm());
        txtWeapon.setText(curriculum.getWeapon());
        txtSparring.setText(curriculum.getSparring());
        txtBoards.setText(curriculum.getBoards());

        //Shows the weapon and basics videos if they exist
        if(selectedRank.equals("Tigers")){
            basics = "tiger_basics";
            weapon = "none";
        }else if(selectedRank.equals("WOY")){
            basics = "woy_basics";
            weapon = "weapon_form";
        }else if(selectedRank.equals("Camo above")){
            basics = "camo_above_basics";
            weapon = "weapon_form";
        }

        //If there are no basics or weapons for the rank group, the buttons are hidden
        if (basics.equals("none")){
            btnWatchBasics.setVisibility(View.INVISIBLE);
        }
        if (weapon.equals("none")){
            btnWatchWeapon.setVisibility(View.INVISIBLE);
        }
        videoView.setVisibility(View.INVISIBLE);

        //Sets the media control to the proper video, makes the player visible, and plays the video
        btnWatchBasics.setOnClickListener(v -> {
            videoView.setVisibility(View.VISIBLE);
            videoView.setMediaController(mediaController);
            if(selectedRank.equals("Tigers")){
                uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.tiger_basics);
            }else if(selectedRank.equals("WOY")){
                uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.woy_basics);
            }else if(selectedRank.equals("Camo above")){
                uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.camo_above_basics);
            }else{
                videoView.setVisibility(View.INVISIBLE);
            }
            videoView.setVideoURI(uri);
            videoView.requestFocus();
            videoView.start();
        });

        btnWatchWeapon.setOnClickListener(v -> {
            if (selectedRank.equals("WOY") || selectedRank.equals("Camo above")) {
                videoView.setVisibility(View.VISIBLE);
                videoView.setMediaController(mediaController);
                uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.weapon_form);
                videoView.setVideoURI(uri);
                videoView.requestFocus();
                videoView.start();
            }else{
                videoView.setVisibility(View.INVISIBLE);
            }
        });

        btnBackFromCurriculumDisplay.setOnClickListener(v -> {
            finish();
        });
    }
}