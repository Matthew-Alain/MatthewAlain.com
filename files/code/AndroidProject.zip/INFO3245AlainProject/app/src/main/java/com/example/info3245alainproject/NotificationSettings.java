package com.example.info3245alainproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;

public class NotificationSettings extends AppCompatActivity {

    CheckBox chkMonday, chkTuesday, chkWednesday, chkThursday, chkFriday, chkSaturday, chkEndOfWeek, chkEndOfMonth;
    ArrayList<Boolean> subscribed;
    Button btnBackFromNotifications;
    DBHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notification_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        chkMonday = findViewById(R.id.chkMonday);
        chkTuesday = findViewById(R.id.chkTuesday);
        chkWednesday = findViewById(R.id.chkWednesday);
        chkThursday = findViewById(R.id.chkThursday);
        chkFriday = findViewById(R.id.chkFriday);
        chkSaturday = findViewById(R.id.chkSaturday);
        chkEndOfWeek = findViewById(R.id.chkEndOfWeek);
        chkEndOfMonth = findViewById(R.id.chkEndOfMonth);
        btnBackFromNotifications = findViewById(R.id.btnBackFromNotifications);

        db = new DBHandler(this);

        //Get the current notification preferences and set the checkboxes accordingly
        subscribed = db.readSettings();
        chkMonday.setChecked(subscribed.get(0));
        chkTuesday.setChecked(subscribed.get(1));
        chkWednesday.setChecked(subscribed.get(2));
        chkThursday.setChecked(subscribed.get(3));
        chkFriday.setChecked(subscribed.get(4));
        chkSaturday.setChecked(subscribed.get(5));
        chkEndOfWeek.setChecked(subscribed.get(6));
        chkEndOfMonth.setChecked(subscribed.get(7));

        btnBackFromNotifications.setOnClickListener(v -> {
            finish();
        });

        //This method is repeated for each notification type:
        //Because Firebase does not have a method to tell whether a user is subscribed to a topic
        //I use the checkboxes to test. If checked, the user is subscribed to the respective topic,
        //so pressing the button should unsubscribe them, and vice versa.
        chkMonday.setOnClickListener(v -> {
            if(!chkMonday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Monday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Monday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Monday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Monday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkTuesday.setOnClickListener(v -> {
            if(!chkTuesday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Tuesday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Tuesday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Tuesday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Tuesday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkWednesday.setOnClickListener(v -> {
            if(!chkWednesday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Wednesday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Wednesday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Wednesday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Wednesday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkThursday.setOnClickListener(v -> {
            if(!chkThursday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Thursday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Thursday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Thursday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Thursday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkFriday.setOnClickListener(v -> {
            if(!chkFriday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Friday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Friday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Friday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Friday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkSaturday.setOnClickListener(v -> {
            if(!chkSaturday.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("Saturday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("Saturday", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("Saturday")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("Saturday", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkEndOfWeek.setOnClickListener(v -> {
            if(!chkEndOfWeek.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("EndOfWeek")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("EndOfWeek", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("EndOfWeek")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("EndOfWeek", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        chkEndOfMonth.setOnClickListener(v -> {
            if(!chkEndOfMonth.isChecked()){
                FirebaseMessaging.getInstance().unsubscribeFromTopic("EndOfMonth")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Unsubscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Unsubscribe failed";
                                }else{
                                    db.updateSetting("EndOfMonth", false);
                                }

                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                FirebaseMessaging.getInstance().subscribeToTopic("EndOfMonth")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }else{
                                    db.updateSetting("EndOfMonth", true);
                                }
                                Toast.makeText(NotificationSettings.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }
}