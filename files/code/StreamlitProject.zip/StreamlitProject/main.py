import streamlit as st
import sqlite3
import os

# Database setup
script_dir = os.path.dirname(__file__)
DATABASE_PATH = os.path.join(script_dir, 'group3.db')

def create_tables():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        email TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        role TEXT NOT NULL,
                        manager_id INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS leave_requests (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        employee_id INTEGER NOT NULL,
                        date_of_application TEXT DEFAULT CURRENT_DATE,
                        leave_type TEXT NOT NULL,
                        manager_id INTEGER NOT NULL,
                        comment TEXT,
                        status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'Approved', 'Rejected')),
                        FOREIGN KEY(manager_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('group3.db')
    c = conn.cursor()
    c.execute('''INSERT OR IGNORE INTO users VALUES (1, 'Matthew Alain', 'Matthew.Alain@company.com', 'MA1', 'Manager', NULL)''')
    c.execute('''INSERT OR IGNORE INTO users VALUES (2, 'David Yao', 'David.Yao@company.com', 'DY1', 'Manager', NULL)''')
    conn.commit()
    conn.close()

    conn = sqlite3.connect('group3.db')
    c = conn.cursor()
    c.execute('''INSERT OR IGNORE INTO users VALUES (3, 'Arda Yazici', 'Arda.Yazici@company.com', 'AY1', 'Manager', NULL)''')
    c.execute('''INSERT OR IGNORE INTO users VALUES (4, 'Jodhveer Atwal', 'Jodhveer.Atwal@company.com', 'JA1', 'Manager', NULL)''')

    conn.commit()
    conn.close()

create_tables()

def add_user_to_db(name, email, password, role, manager_id=None):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (name, email, password, role, manager_id) VALUES (?, ?, ?, ?, ?)",
                       (name, email, password, role, manager_id))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()

def get_user_from_db(email):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email, password, role, manager_id FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return {"id": user[0], "name": user[1], "email": user[2], "password": user[3], "role": user[4], "manager_id": user[5]}
    return None

def get_managers_from_db():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, email FROM users WHERE role = 'Manager'")
    managers = cursor.fetchall()
    conn.close()
    return [{"id": m[0], "name": m[1], "email": m[2]} for m in managers]

def add_leave_request_to_db(employee_id, leave_type, manager_id, comment=None):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO leave_requests (employee_id, leave_type, manager_id, comment) VALUES (?, ?, ?, ?)",
                    (employee_id, leave_type, manager_id, comment))
    conn.commit()
    conn.close()
    

def get_employee_leaves_from_db(employee_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT lr.date_of_application, lr.leave_type, lr.comment, lr.status
        FROM leave_requests lr
        WHERE lr.employee_id = ?
        ORDER BY lr.date_of_application DESC
        LIMIT 10
    """, (employee_id,))
    leaves = cursor.fetchall()
    conn.close()
    return [{"Date": leave[0], "Type": leave[1], "Comment": leave[2], "Status": leave[3]} for leave in leaves]

def get_pending_leaves_for_manager_from_db(manager_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT lr.id, u.name, lr.date_of_application, lr.leave_type, lr.comment, lr.status
        FROM leave_requests lr
        JOIN users u ON lr.employee_id = u.id
        WHERE lr.manager_id = ? AND lr.status = 'Pending'
        ORDER BY lr.date_of_application
    """, (manager_id,))
    leaves = cursor.fetchall()
    conn.close()
    return [{"id": leave[0], "employee_name": leave[1], "date_of_application": leave[2], "leave_type": leave[3], "comment": leave[4], "status": leave[5]} for leave in leaves]

def update_leave_status_in_db(leave_id, status):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE leave_requests SET status = ? WHERE id = ?", (status, leave_id))
    conn.commit()
    conn.close()

def get_user_name_from_id(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM users WHERE id = ?", (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

def get_user_id_from_email(email):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

# Session state setup
if "page" not in st.session_state:
    st.session_state['page'] = "login"

if "currentUser" not in st.session_state:
    st.session_state['currentUser'] = None

# Page switcher
def changePage(target):
    st.session_state['page'] = target

# Login Page
def login():
    st.title("Leave Management System")
    st.header("Login")

    login_email = st.text_input("Email", key="login_email")
    login_pass = st.text_input("Password", type="password", key="login_pass")

    if st.button("Login"):
        user = get_user_from_db(login_email)
        if user and user['password'] == login_pass:
            st.success("Login successful")
            st.session_state['currentUser'] = login_email
            if user['role'] == "Employee":
                changePage("employee")
            else:
                changePage("manager")
        else:
            st.error("Invalid email or password")

    st.button("Go to Sign Up", on_click=changePage, args=("signup",))

# Sign-Up Page
def signup():
    st.title("Leave Management System")
    st.header("Sign Up")

    reg_name = st.text_input("Full Name", key="reg_name")
    reg_email = st.text_input("Email", key="reg_email")
    reg_password = st.text_input("Password", type="password", key="reg_password")
    reg_confirm = st.text_input("Confirm Password", type="password", key="reg_confirm")
    reg_role = st.selectbox("Role", ["Employee", "Manager"], key="reg_role")

    managers_list = get_managers_from_db()
    manager_options = [m["name"] + " (" + m["email"] + ")" for m in managers_list]
    selected_manager_id = None
    if reg_role == "Employee" and manager_options:
        selected_manager_display = st.selectbox("Select Manager", manager_options)
        selected_manager_email = selected_manager_display.split(" (")[1][:-1]
        manager = get_user_from_db(selected_manager_email)
        selected_manager_id = manager['id'] if manager else None

    if st.button("Register"):
        if reg_password != reg_confirm:
            st.error("Passwords do not match")
        elif get_user_from_db(reg_email):
            st.error("Email already registered")
        elif not reg_name or not reg_email or not reg_password or not reg_role:
            st.error("Please fill in all fields")
        elif reg_role == "Employee" and selected_manager_id is None and manager_options:
            st.error("Please select a manager")
        else:
            user_id = add_user_to_db(reg_name, reg_email, reg_password, reg_role, selected_manager_id)
            if user_id:
                st.success("Registration successful! You may now log in.")
            else:
                st.error("Registration failed. Please try again.")

    st.button("Back to Login", on_click=changePage, args=("login",))

# Employee Page
def employee():
    st.title("Employee Dashboard")
    current_user_email = st.session_state['currentUser']
    user_info = get_user_from_db(current_user_email)
    if user_info:
        st.write("Welcome,", user_info['name'])

        st.subheader("Apply for Leave")
        with st.form("leave_form"):
            leave_type = st.selectbox("Leave Type", ["Personal", "Sick", "Official"])
            leave_comment = st.text_area("Reason for Leave")
            submit_button = st.form_submit_button("Submit Leave Request")

            if submit_button:
                manager_id = user_info['manager_id']
                if manager_id:
                    add_leave_request_to_db(user_info['id'], leave_type, manager_id, leave_comment)
                    st.success("Leave request submitted successfully!")
                else:
                    st.error("Your manager is not assigned. Please contact the administrator.")

        st.subheader("Your Leave Requests (Maximum of 10)")
        leave_requests = get_employee_leaves_from_db(user_info['id'])

        if leave_requests:
            st.table(leave_requests)
        else:
            st.info("No Active Leave Requests.")

        st.button("Logout", on_click=changePage, args=("login",))
    else:
        st.error("Could not retrieve user information. Please log in again.")
        changePage("login")

# Manager Page
def manager():
    st.title("Manager Dashboard")
    current_user_email = st.session_state['currentUser']
    manager_info = get_user_from_db(current_user_email)
    if manager_info:
        st.write("Welcome,", manager_info['name'])

        pending_leaves = get_pending_leaves_for_manager_from_db(manager_info['id'])

        if pending_leaves:
            st.subheader("Pending Leave Requests")
            for request in pending_leaves:
                st.write(f"**Employee Name:** {request['employee_name']}")
                st.write(f"**Date of Application:** {request['date_of_application']}")
                st.write(f"**Leave Type:** {request['leave_type']}")
                st.write(f"**Comment:** {request['comment']}")
                st.write(f"**Status:** {request['status']}")

                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"Approve {request['id']}"):
                        update_leave_status_in_db(request['id'], "Approved")
                        st.rerun() # Refresh to update the displayed list
                with col2:
                    if st.button(f"Reject {request['id']}"):
                        update_leave_status_in_db(request['id'], "Rejected")
                        st.rerun() # Refresh to update the displayed list
                st.write("---")
        else:
            st.info("No pending leave requests to display.")

        st.button("Logout", on_click=changePage, args=("login",))
    else:
        st.error("Could not retrieve user information. Please log in again.")
        changePage("login")

# Routing
pages = {
    "login": login,
    "signup": signup,
    "employee": employee,
    "manager": manager
}

# Session state setup
if "page" not in st.session_state:
    st.session_state['page'] = "login"

if "currentUser" not in st.session_state:
    st.session_state['currentUser'] = None

# Page switcher
def changePage(target):
    st.session_state['page'] = target

pages[st.session_state['page']]()