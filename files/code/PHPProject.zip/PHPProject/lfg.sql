-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2024 at 07:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lfg`
--

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

CREATE TABLE `genres` (
  `genreid` int(2) NOT NULL,
  `genrename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `genres`
--

INSERT INTO `genres` (`genreid`, `genrename`) VALUES
(0, 'Platform'),
(1, 'Shooter'),
(2, 'Fighting'),
(3, 'Survival'),
(4, 'Sandbox'),
(5, 'Rhythm'),
(6, 'Adventure'),
(7, 'RPG'),
(8, 'Roguelike'),
(9, 'Simulation'),
(10, 'Real-Time Strategy'),
(11, 'Turn-Based Strategy'),
(12, 'Tower Defense'),
(13, 'Horror'),
(14, 'Party'),
(15, 'Puzzle');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `postID` int(11) NOT NULL,
  `roleID` int(11) NOT NULL,
  `yearsExperience` int(2) NOT NULL DEFAULT 0,
  `postTitle` varchar(100) NOT NULL,
  `postContent` varchar(255) NOT NULL,
  `closeDate` varchar(10) NOT NULL DEFAULT current_timestamp(),
  `user` varchar(30) NOT NULL DEFAULT 'DefaultUser',
  `contact` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`postID`, `roleID`, `yearsExperience`, `postTitle`, `postContent`, `closeDate`, `user`, `contact`) VALUES
(44, 1, 2, 'Looking for Programmer!', 'I am looking for a programmer to help me code my new game! It will be an open-world FPS MMO, with inspiration from games like WoW, Halo, and Final Fantasy!', '2024-12-09', 'matt', 'matthew.alain@student.kpu.ca'),
(45, 8, 0, 'Need help with narrative!', 'I am looking for someone to help me write the narrative for my game! I have a few ideas, but I really just want someone to help bounce ideas off of! Looking forward to hearing from you!', '2024-12-27', 'NewUser', 'Testemail@gmail.com'),
(46, 6, 10, 'Can Someone Make My Game Sound Good?', 'I really need someone to help me with my audio mixing for my rhythm game! I\'m only looking for professionals who have a lot of experience.', '2024-12-06', 'EvenNewerUser', 'anotherEmail@gmail.com'),
(47, 6, 2, 'Looking for Audio Engineer', 'I am looking for an audio engineer!', '2024-12-31', 'NewAccount', 'NewEmail@gmail.com'),
(48, 5, 4, 'New Game Idea!', 'I\'m looking for a 3D modeller to help me with my new simulation game idea!', '2025-01-01', 'NewAccount', 'ExampleEmail@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `roleID` int(11) NOT NULL,
  `roleName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roleID`, `roleName`) VALUES
(1, 'Programmer'),
(2, 'Artist'),
(3, 'Tester'),
(4, 'UX / UI'),
(5, '3D Modeller'),
(6, 'Audio Engineer'),
(7, 'Networking Engineer'),
(8, 'Narrative Designer');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `statusid` int(1) NOT NULL,
  `statusname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`statusid`, `statusname`) VALUES
(0, 'Do Not Disturb'),
(1, 'Open to Work'),
(2, 'Actively Looking');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `passwordhash` varchar(100) NOT NULL,
  `status` int(1) NOT NULL,
  `motd` varchar(100) NOT NULL,
  `contactinfo` varchar(100) NOT NULL,
  `role` int(1) NOT NULL,
  `yearsofexperience` int(2) NOT NULL,
  `genres` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `passwordhash`, `status`, `motd`, `contactinfo`, `role`, `yearsofexperience`, `genres`) VALUES
('matt', 'matthew.alain@student.kpu.ca', '$2y$10$3WSre/CMNeXJ.YvU6NXuUei97ityyz2sUN3oegZT45efXnuJYqlhO', 0, '', '', 0, 0, ''),
('NewUser', 'Testemail@gmail.com', '$2y$10$.g4koxSZLOTWFa3OgNURiOlB7F.s5mtOHshr.NJz7YM.ZW/E2jcEe', 0, '', '', 0, 0, ''),
('EvenNewerUser', 'anotherEmail@gmail.com', '$2y$10$67ojPLgutAZ6k9ACcu3MmOD0k31wt9LL4wmp./hguOiZeVUbXx2sm', 0, '', '', 0, 0, ''),
('NewAccount', 'NewEmail@gmail.com', '$2y$10$prUeVdE61eD2MhmbswNlCOxlUbye4zqqW28AJYS7RwKpHBvtg2jR6', 0, '', '', 0, 0, ''),
('NewAccount', 'NewEmail@gmail.com', '$2y$10$M6AEOjYzrSLM3KpfeHsZ1eN9GmFDi1lFETF9671ho7ra2OlHKXtom', 0, '', '', 0, 0, ''),
('NewAccount', 'NewEmail@gmail.com', '$2y$10$c28cjOCnHivtH/aIyUKJMO/2uZWM3HvP//zOC4R9KFrtKR1/9D//6', 0, '', '', 0, 0, ''),
('NewAccount', 'ExampleEmail@gmail.com', '$2y$10$HTD.gTth/fXDBEzbh.RCg.qUpz7SPsvS.dHhf842RMO1LTBUNvI3O', 0, '', '', 0, 0, ''),
('Quincunx005', 'quincunx005@gmail.com', '$2y$10$F8kef2VD0Kt05ALjo6FnNeijdt9vI0C3chbp/f0KxCUZMYTioLbnu', 0, '', '', 0, 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`genreid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`postID`),
  ADD UNIQUE KEY `productCode` (`postTitle`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`roleID`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`statusid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `postID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
